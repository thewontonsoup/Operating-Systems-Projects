#include "hw1.h"
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <ctype.h>
// main program
#define MAX_FILE_LEN 100
#define MAX_ARRAY_LEN 1000

int is_number(const char *str);

int main (int argc, char *argv[])
{
    int exit_status = 0;

	//First implement count lines.
    FILE *fp;
    int count_lines = 0;
    char filename[MAX_FILE_LEN];
    char ch;
    bool hasO = false;

    int specialChars[128] = {0};
    int count_specials = 0;

    int count_nums = 0;
    int num_spaces = 0;
  // printf("Number of arguments: %d\n", argc);
    if (argc <= 1){return 1;}

    //Case where there it is L.
    else if (strcmp(argv[1], "-L")==0){
        if (argc > 2){
            return 1;
        }
        ch = getchar();
        if(ch  == EOF){
            return 2;
        }
        while (ch != EOF){
                if(ch == '\n'){
                    count_lines++;
                }
                ch = getchar();
            }
        printf("%d\n", count_lines);
        }
    //printf("Number of arguments: %d\n", argc);
    //Case where there is an S
     else if (strcmp(argv[1], "-S")==0){
        if(argc > 3 || argc == 3 && strcmp(argv[2], "-O")!=0){return 1;}
        if(argc == 3 && strcmp(argv[2], "-O") == 0){hasO = true;}
        ch = getchar();
        if(ch == EOF){
            return 2;
        }
        while (ch != EOF){
            if(ch <= 126 && ch >=33 && !isalnum(ch)){
                specialChars[(int)ch]++;
                count_specials++;
            }
            ch = getchar();
        }
        if(hasO){
            for(int i = 0; i < 128; i++){
                if(specialChars[i] > 0){
                fprintf(stderr, "%c %d\n", i, specialChars[i]);
                }
            }
        }
         printf("%d\n", count_specials);
     }
     //printf("Number of arguments: %d\n", argc);
     //Case where there is a N
     else if (strcmp(argv[1], "-N")==0){
        if(argc > 3 || argc == 3 && strcmp(argv[2], "-O")!=0){return 1;}
        if(argc == 3 && strcmp(argv[2], "-O") == 0){hasO = true;}
        ch = getchar();
        if(ch  == EOF){
            return 2;
        }
        //That way just print one at a time.
        if(hasO){
            while (ch !=EOF){
                if(isdigit(ch)){
                    do{
                    fprintf(stderr, "%c", ch);
                    ch = getchar(); 
                }while (isdigit(ch));
                count_nums++;
                fprintf(stderr,"\n");
            }
                ch = getchar();
            }
            }
        
        else{
            while(ch !=EOF){
                if(isdigit(ch)){
                    do{
                        ch = getchar();
                    }while (isdigit(ch));
                count_nums++;
                }
                ch = getchar();
            }
        }
       
       printf("%d\n", count_nums);
    }
    else if(strcmp(argv[1], "-C") == 0){

        if(argc > 4 || argc < 3 || argc == 4 && strcmp(argv[3], "-O") != 0){return 1;}
        
        if(!is_number(argv[2])){return 1;}
        num_spaces = atoi(argv[2]);
        ch = getchar();
        if(ch == EOF){return 2;}

        int temp_spaces = 0;
        int total_spaces = 0;

        while(ch != EOF){
            if(ch == ' '){
                temp_spaces++;
                if(temp_spaces == num_spaces){
                    fprintf(stderr, "\t");
                    temp_spaces = 0;
                    total_spaces++;
                }
            }
            else{
                for(int i = 0; i < temp_spaces; i++){
                    fprintf(stderr, " ");
                }
                temp_spaces = 0;
                fprintf(stderr, "%c", ch);
            }
            ch = getchar();
        }
        printf("%d\n", total_spaces);
    }
    else if(strcmp(argv[1], "-W") == 0){
        if(argc > 3 || argc == 3 && strcmp(argv[2], "-O")!= 0){return 1;}
        ch = getchar();
        if(ch == EOF){return 2;}
        
        int total_lines = 0;
        int is_blank = 1;
        int has_leading = 0;
        long from_last_non = 0;
        int prev_space = 0;
        char whitespace[1024];
        //Count the number of blank lines
        while(ch != EOF){
            if(ch == '\n'){
                if(is_blank || has_leading || prev_space){
                    total_lines++;
                }
                if(!is_blank){fprintf(stderr, "\n");}
                is_blank = 1;
                has_leading = 0;
                prev_space = 0;
            }
            else if(isspace(ch)) {prev_space = 1;
                if(is_blank){has_leading = 1;}
                else{from_last_non++; whitespace[from_last_non-1] = ch;}
            }
            else if(!isspace(ch)){
                if(from_last_non > 0 && !is_blank){
                    for(int i = 0; i < from_last_non; i++){
                        fprintf(stderr, "%c", whitespace[i]);
                    }
                }
                is_blank = 0;
                prev_space = 0;
                fprintf(stderr, "%c", ch);
                from_last_non = 0;
            }
            ch = getchar();
        }
        if((has_leading || is_blank || prev_space) && ch == EOF){total_lines++;}
        printf("%d\n", total_lines);
    }
    else{

        exit_status = 1;
    }
    /*
    // Loop through and print each argument
    for (int i = 0; i < argc; i++) {
        printf("Argument %d: %s\n", i, argv[i]);
    }

    char buffer[256];

    // Read from stdin, which is redirected from rsrc/theBIGC.txt
    while (fgets(buffer, sizeof(buffer), stdin) != NULL) {
        // Process each line of the file here (for example, print it)
        printf("%s", buffer);
    }
    */

	return exit_status;
}

int is_number(const char *str){
    if (*str == '\0') return 0;
    while(*str){
        if(!isdigit(*str)) return 0;
        str++;
    }
    
    return 1; 
}

