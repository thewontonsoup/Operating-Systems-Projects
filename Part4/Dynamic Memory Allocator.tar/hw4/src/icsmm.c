#include "icsmm.h"
#include "debug.h"
#include "helpers.h"
#include <stdio.h>
#include <stdlib.h>
#define PAGE_SIZE 4096
/*
 * The allocator MUST store the head of its free list in this variable. 
 * Doing so will make it accessible via the extern keyword.
 * This will allow ics_freelist_print to access the value from a different file.
 */
ics_free_header *freelist_head = NULL;

/*
 * The allocator MUST use this pointer to refer to the position in the free list to 
 * starting searching from. 
 */
ics_free_header *freelist_next = NULL;

void * heap_start = NULL;
void * heap_end = NULL;
int has_been_called = 0;

/*
 * This is your implementation of malloc. It acquires uninitialized memory from  
 * ics_inc_brk() that is 16-byte aligned, as needed.
 *
 * @param size The number of bytes requested to be allocated.
 *
 * @return If successful, the pointer to a valid region of memory of at least the
 * requested size is returned. Otherwise, NULL is returned and errno is set to 
 * ENOMEM - representing failure to allocate space for the request.
 * 
 * If size is 0, then NULL is returned and errno is set to EINVAL - representing
 * an invalid request.
 */

int initialize_heap(){
    void *new_page = ics_inc_brk();
    if(new_page == (void *) -1){
        errno = ENOMEM;
        return -1;
    }

    if(freelist_head == NULL && has_been_called == 0){
          // Create the prologue footer
    has_been_called = 1;
    heap_start = new_page;
    ics_footer *prologue = (ics_footer *)new_page;
    prologue->block_size = 0 | 1;  // Size 0 with allocated bit set
    prologue->fid = FOOTER_MAGIC;
    prologue-> requested_size = 0;

    ics_free_header *initial_free_block = (ics_free_header *)((char *)new_page + sizeof(ics_footer));
    initial_free_block->header.block_size = ((PAGE_SIZE - sizeof(ics_footer) - sizeof(ics_header)) & 0xFFFE) | 0;
    initial_free_block->header.hid = HEADER_MAGIC;

    //Adds the footer for the free block
    ics_footer *initial_footer = (ics_footer *)((char *)initial_free_block + initial_free_block->header.block_size - sizeof(ics_footer));
        initial_footer->block_size = initial_free_block->header.block_size;
        initial_footer->fid = FOOTER_MAGIC;
    //Finally create the epilogue header
    heap_end = (void *) ((char *)new_page + PAGE_SIZE); 
    ics_header *epilogue = (ics_header *)((char *)new_page + PAGE_SIZE - sizeof(ics_header));
    epilogue->block_size = 0 | 1;  // Size 0 with allocated bit set
    epilogue->hid = HEADER_MAGIC;

    freelist_head = freelist_next = initial_free_block;
    initial_free_block -> next = initial_free_block -> prev = NULL;
    return 0;
    }
    if(freelist_head == NULL){
        ics_free_header *new_free_block = (ics_free_header *)((char *)new_page - sizeof(ics_header));
        new_free_block -> header.block_size = ((PAGE_SIZE & 0xFFFE)) | 0;
        new_free_block -> header.hid = HEADER_MAGIC;

        ics_footer *new_footer = (ics_footer *)((char *)new_free_block + new_free_block -> header.block_size -sizeof(ics_footer));
        new_footer -> block_size = new_free_block-> header.block_size;
        new_footer -> fid = FOOTER_MAGIC;

        freelist_head = freelist_next = new_free_block; 
        new_free_block -> next = NULL;
        new_free_block -> prev = NULL;

        ics_header *new_epilogue = (ics_header *)((char *) new_page + PAGE_SIZE-sizeof(ics_header));
        heap_end = (void *) ((char *)new_page + PAGE_SIZE);
        new_epilogue -> block_size = 0 | 1;
        new_epilogue -> hid = HEADER_MAGIC;
        return 0;
    }

    ics_free_header *last_block = freelist_head;
    while(last_block -> next){
        last_block = last_block -> next;
    }
    //If the last block is free Need to consider epilogue as well as last block..
    char *last_block_end = (char *)last_block + (last_block -> header.block_size & 0xFFFE)+sizeof(ics_header);

    if(!(last_block -> header.block_size & 1) && last_block_end == (char *) new_page){ 
        //Add the new page and append a new footer
        last_block -> header.block_size += PAGE_SIZE;
        ics_footer *new_footer = (ics_footer *)((char *)new_page + PAGE_SIZE -sizeof(ics_footer));
        new_footer -> block_size = last_block -> header.block_size;
        new_footer -> fid = FOOTER_MAGIC;
    }
    else{ //Just create a new free block at the new page.
        ics_free_header *new_free_block = (ics_free_header *)((char *)new_page - sizeof(ics_header));
        new_free_block -> header.block_size = ((PAGE_SIZE & 0xFFFE)) | 0;
        new_free_block -> header.hid = HEADER_MAGIC;
        
        ics_footer *new_footer = (ics_footer *)((char *)new_free_block + new_free_block -> header.block_size -sizeof(ics_footer));
        new_footer -> block_size = new_free_block-> header.block_size;
        new_footer -> fid = FOOTER_MAGIC;

        last_block -> next = new_free_block;
        new_free_block -> prev = last_block;
        new_free_block -> next = NULL;
    }
    ics_header *new_epilogue = (ics_header *)((char *) new_page + PAGE_SIZE-sizeof(ics_header));
    heap_end = (void *) ((char *)new_page + PAGE_SIZE);
    new_epilogue -> block_size = 0 | 1;
    new_epilogue -> hid = HEADER_MAGIC;
    return 0;
}

void *ics_malloc(size_t size) {
    if (size == 0){
        errno = EINVAL;
        return NULL;
    }
    size_t aligned_size = (size + 15) & ~0xF;
    size_t total_size = aligned_size + sizeof(ics_header) +sizeof(ics_footer);

    size_t min_block_size = 32;
    //This either searches from the header or the next depending on which is NULL.
    ics_free_header *current = freelist_next ? freelist_next : freelist_head;
    ics_free_header *start = current;

    while(current){
        if(current -> header.block_size >= total_size){
        //printf("This is the total size %d and block size %ld \n", current -> header.block_size, total_size);
            size_t remaining_size = current-> header.block_size - total_size;
        // printf("This is remaining %ld \n", remaining_size);
            if(remaining_size >= min_block_size){
                current -> header.block_size = total_size;
                //Create a new free block from remainig 
                ics_free_header *new_free_block = (ics_free_header *)((char *) current + total_size);
                new_free_block -> header.block_size = (remaining_size & 0xFFFE) | 0;
                new_free_block -> header.hid = HEADER_MAGIC;

                //Update Footer of the new free block.
                ics_footer *new_footer = (ics_footer *)((char *) new_free_block + remaining_size -sizeof(ics_footer));
                new_footer -> block_size = new_free_block -> header.block_size;
                new_footer -> fid = FOOTER_MAGIC;

                //Insert the new freed block in address order.
                new_free_block -> next = current -> next;
                new_free_block -> prev = current -> prev;
                if(current-> prev) current -> prev -> next = new_free_block;
                if(current -> next) current -> next -> prev = new_free_block;
                if(current == freelist_head) freelist_head = new_free_block;
                current -> next = new_free_block;

            }
            else{
                if(current -> prev) current -> prev -> next = current -> next;
                if(current -> next) current -> next -> prev = current -> prev;
                if(current == freelist_head) freelist_head = current -> next;
            }
            current-> header.hid = HEADER_MAGIC;
            current -> header.requested_size = size;
            if(remaining_size >= min_block_size){
                current -> header.block_size =  (total_size & 0xFFFE) | 1;
            }
            else{
                current -> header.block_size =  (current -> header.block_size & 0xFFFE) | 1;
            }
            ics_footer *ftr = (ics_footer*)((char *) current + (current->header.block_size & 0xFFFE) -sizeof(ics_footer));
            ftr-> block_size = current -> header.block_size;
            ftr -> fid = FOOTER_MAGIC;
            ftr -> requested_size = size;

            freelist_next = current-> next ? current -> next : freelist_head;
            return (void *)((char *)current + sizeof(ics_header));
        }
        current = current -> next ? current -> next: freelist_head;
        if(current == start) break;
    }

    if(initialize_heap() == -1) return NULL;

    return ics_malloc(size);
}

/*
 * Marks a dynamically allocated block as no longer in use and coalesces with 
 * adjacent free blocks (as specified by Homework Document). 
 * Adds the block to the appropriate bucket according to the block placement policy.
 *
 * @param ptr Address of dynamically allocated memory returned by the function
 * ics_malloc.
 * 
 * @return 0 upon success, -1 if error and set errno accordingly.
 * 
 * If the address of the memory being freed is not valid, this function sets errno
 * to EINVAL. To determine if a ptr is not valid, (i) the header and footer are in
 * the managed  heap space, (ii) check the hid field of the ptr's header for
 * special value (iii) check the fid field of the ptr's footer for special value,
 * (iv) check that the block_size in the ptr's header and footer are equal, (v) 
 * the allocated bit is set in both ptr's header and footer, and (vi) the 
 * requested_size is identical in the header and footer.

 */
int valid_ptr(void * ptr){
    if(!ptr) return 0;  //If the pointer is valid, and the poitner is in range.
    if((void *) ptr <= heap_start || (void *) ptr >= heap_end) return 0;

    //Nextcheck the contents.
    ics_header * header = (ics_header *)((char *) ptr - sizeof(ics_header));
    ics_footer * footer = (ics_footer *)((char *) header + (header -> block_size & 0xFFFE) - sizeof(ics_footer));
    
    if((header -> block_size & 1) == 0 || (footer -> block_size & 1) == 0) return 0;
    if(header -> hid != HEADER_MAGIC || footer -> fid != FOOTER_MAGIC) return 0;
    if(header -> block_size != footer -> block_size) return 0;
    if(header -> requested_size != footer -> requested_size) return 0;

    return 1;
}

int ics_free(void *ptr) {
    if(!ptr || !valid_ptr(ptr)){
        errno = EINVAL;
        return -1;
    }
    
    ics_header * cur_header = (ics_header *)((char *) ptr - sizeof(ics_header));
    ics_footer * cur_footer = (ics_footer *)((char *) cur_header + (cur_header -> block_size & 0xFFFE) - sizeof(ics_footer));

    cur_header -> block_size &= 0xFFFE;
    cur_footer -> block_size &= 0xFFFE;

    ics_free_header *free_block = (ics_free_header *) cur_header;
    free_block -> header.block_size = cur_header -> block_size;

    ics_footer *prev_footer = (ics_footer *)((char *)cur_header - sizeof(ics_footer));
    //If the next header is unallocated, attempt to coalesce.
    if((prev_footer->block_size & 1) == 0 && prev_footer ->fid == FOOTER_MAGIC && (void *) prev_footer > heap_start){
        ics_header *prev_header = (ics_header *)((char *)prev_footer - (prev_footer -> block_size & 0xFFFE) + sizeof(ics_footer));
        if((void *) prev_header >  heap_start && prev_header -> hid == HEADER_MAGIC && prev_header -> block_size == prev_footer -> block_size){

            ics_free_header *prev_free = (ics_free_header *)prev_header;

            prev_free -> header.block_size = cur_header -> block_size  + prev_header -> block_size;
            cur_footer -> block_size = prev_free -> header.block_size;
            cur_footer -> fid = FOOTER_MAGIC;
            if(freelist_head == NULL){
                freelist_head = freelist_next = prev_free;
            }

            return 0;
        }
    }
    ics_free_header *current = freelist_head;
    ics_free_header *prev = NULL;
    while(current && (void *) current < (void *)free_block){
        prev = current;
        current = current -> next;
    }
    free_block -> next = current;
    free_block -> prev = prev;

    if(!current && !prev) freelist_next = free_block;

    if(current) current ->prev = free_block;
    if(prev) prev -> next = free_block;
    else freelist_head  = free_block;

    return 0;
}

/*
 * Resizes the dynamically allocated memory, pointed to by ptr, to at least size 
 * bytes. See Homework Document for specific description.
 *
 * @param ptr Address of the previously allocated memory region.
 * @param size The minimum size to resize the allocated memory to.
 * @return If successful, the pointer to the block of allocated memory is
 * returned. Else, NULL is returned and errno is set appropriately.
 *
 * If there is no memory available ics_malloc will set errno to ENOMEM. 
 *
 * If ics_realloc is called with an invalid pointer, set errno to EINVAL. See ics_free
 * for more details.
 *
 * If ics_realloc is called with a valid pointer and a size of 0, the allocated     
 * block is free'd and return NULL.
 */
void *ics_realloc(void *ptr, size_t size) {
    if (!ptr || !valid_ptr(ptr)){
        errno = EINVAL;
        return NULL;
    }
    if (size == 0) { ics_free(ptr); return NULL; } // Free if size 0

    // Retrieve current block header and footer
    ics_header *hdr = (ics_header *)((char *) ptr - sizeof(ics_header));

    size_t current_size = hdr->block_size - sizeof(ics_header) - sizeof(ics_footer);

    if (current_size >= size){
        current_size = size;
    }
    // Allocate new block and copy data
    void *new_ptr = ics_malloc(size);
    if(!new_ptr){ errno = ENOMEM; return NULL;}
    else{
        memcpy(new_ptr, ptr, current_size);
        ics_free(ptr); // Free old block
    }
    return new_ptr;
}
